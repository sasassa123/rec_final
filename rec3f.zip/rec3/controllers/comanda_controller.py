from datetime import datetime
from decimal import Decimal

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from models import db, Comanda, ItemCardapio, ItemComanda, Cliente
from utils.decorators import role_required

comanda_bp = Blueprint("comanda", __name__)




@comanda_bp.route("/lista")
@login_required
@role_required("cliente", "atendente", "admin")
def listar_comandas():
    if current_user.has_role("cliente"):
        comandas = Comanda.query.filter_by(cliente_id=current_user.cliente_id).all()
        clientes = [] 
    else:
        comandas = Comanda.query.order_by(Comanda.id.desc()).all()
        clientes = Cliente.query.all()  

    return render_template(
        "comandas_listar.html",
        comandas=comandas,
        clientes=clientes
    )



@comanda_bp.route("/nova", methods=["POST"])
@login_required
@role_required("cliente", "atendente", "admin")
def criar_comanda():

    if current_user.has_role("cliente"):
        cliente_id = current_user.cliente_id
        atendente_id = None

   
    elif current_user.has_role("atendente"):
        cliente_id = request.form.get("cliente_id")

        if not cliente_id:
            flash("Selecione um cliente para abrir a comanda.", "danger")
            return redirect(url_for("comanda.listar_comandas"))

        cliente_id = int(cliente_id)
        atendente_id = current_user.funcionario.id

    
    else:
        cliente_id = request.form.get("cliente_id")

        if not cliente_id:
            flash("Selecione um cliente.", "danger")
            return redirect(url_for("comanda.listar_comandas"))

        cliente_id = int(cliente_id)
        atendente_id = None

   
    comanda = Comanda(
        status="aberta",
        cliente_id=cliente_id,
        atendente_id=atendente_id,
        created_by_user_id=current_user.id,
    )

    db.session.add(comanda)
    db.session.commit()

    flash(f"Comanda {comanda.id} criada com sucesso!", "success")
    return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda.id))



@comanda_bp.route("/<int:comanda_id>")
@login_required
def detalhar_comanda(comanda_id):
    comanda = Comanda.query.get_or_404(comanda_id)

    
    if current_user.has_role("cliente") and comanda.cliente_id != current_user.cliente_id:
        flash("Você não pode acessar esta comanda.", "danger")
        return redirect(url_for("comanda.listar_comandas"))

    itens_cardapio = ItemCardapio.query.filter_by(disponivel=True).all()
    return render_template("comanda_detalhe.html", comanda=comanda, itens_cardapio=itens_cardapio)



@comanda_bp.route("/<int:comanda_id>/add_item", methods=["POST"])
@login_required
def adicionar_item(comanda_id):
    comanda = Comanda.query.get_or_404(comanda_id)

    
    if current_user.has_role("cliente"):
        if comanda.cliente_id != current_user.cliente_id:
            flash("Você não pode mexer nessa comanda.", "danger")
            return redirect(url_for("comanda.listar_comandas"))

  
    if comanda.status == "fechada" and not current_user.has_role("admin"):
        flash("Somente administradores podem editar comandas fechadas.", "danger")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    if comanda.status == "paga":
        flash("Comandas pagas não podem ser editadas.", "danger")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    item_id = int(request.form.get("item_id"))
    quantidade = int(request.form.get("quantidade") or 0)

    if quantidade <= 0:
        flash("Quantidade inválida.", "warning")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    item = ItemCardapio.query.get_or_404(item_id)

    if not item.disponivel:
        flash("Item indisponível.", "warning")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    ic = ItemComanda(
        comanda_id=comanda.id,
        item_cardapio_id=item.id,
        quantidade=quantidade,
        preco_unitario=item.preco,
        subtotal=item.preco * quantidade
    )

    db.session.add(ic)
    db.session.commit()

    flash("Item adicionado com sucesso.", "success")
    return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))



@comanda_bp.route("/item/<int:item_id>/remover", methods=["POST"])
@login_required
def remover_item(item_id):
    item = ItemComanda.query.get_or_404(item_id)
    comanda = item.comanda

    
    if current_user.has_role("cliente"):
        if comanda.cliente_id != current_user.cliente_id:
            flash("Você não pode mexer nessa comanda.", "danger")
            return redirect(url_for("comanda.listar_comandas"))

    
    if comanda.status == "fechada" and not current_user.has_role("admin"):
        flash("Somente administradores podem editar comandas fechadas.", "danger")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda.id))

    if comanda.status == "paga":
        flash("Comandas pagas não podem ser editadas.", "danger")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda.id))

    db.session.delete(item)
    db.session.commit()

    flash("Item removido.", "info")
    return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda.id))


@comanda_bp.route("/<int:comanda_id>/fechar", methods=["POST"])
@login_required
@role_required("atendente", "admin")
def fechar(comanda_id):
    comanda = Comanda.query.get_or_404(comanda_id)

    if comanda.status != "aberta":
        flash("A comanda não está aberta.", "warning")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    if len(comanda.itens) == 0:
        flash("Não é possível fechar uma comanda sem itens.", "warning")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    comanda.status = "fechada"
    comanda.closed_at = datetime.utcnow()
    comanda.closed_by_user_id = current_user.id

    db.session.commit()

    flash("Comanda fechada com sucesso!", "success")
    return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))
