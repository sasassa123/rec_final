from flask import Blueprint, render_template
from flask_login import login_required
from utils.decorators import role_required

from models import ItemCardapio

cardapio_bp = Blueprint("cardapio", __name__)

@cardapio_bp.route("/")
@login_required
@role_required("cliente", "atendente", "admin")
def ver_cardapio():
    itens = ItemCardapio.query.filter_by(disponivel=True).all()
    return render_template("cardapio.html", itens=itens)
