from models import db, Role, User, Funcionario, ItemCardapio


def seed_inicial():
    
    if Role.query.count() == 0:
        db.session.add_all([
            Role(nome="cliente"),
            Role(nome="atendente"),
            Role(nome="admin"),
        ])
        db.session.commit()

    
    if User.query.filter_by(username="admin").first() is None:
        role_admin = Role.query.filter_by(nome="admin").first()
        func = Funcionario(nome="Administrador", cargo="admin", ativo=True)
        db.session.add(func)
        db.session.flush()

        admin = User(username="admin", role=role_admin, funcionario=func)
        admin.set_password("admin123")
        db.session.add(admin)
        db.session.commit()

   
    if User.query.filter_by(username="atendente").first() is None:
        role_atendente = Role.query.filter_by(nome="atendente").first()
        func = Funcionario(nome="Atendente Padrão", cargo="atendente", ativo=True)
        db.session.add(func)
        db.session.flush()

        atendente = User(username="atendente", role=role_atendente, funcionario=func)
        atendente.set_password("atendente123")
        db.session.add(atendente)
        db.session.commit()

    
    if User.query.filter_by(username="cliente").first() is None:
        role_cliente = Role.query.filter_by(nome="cliente").first()

        cliente = User(username="cliente", role=role_cliente)
        cliente.set_password("cliente123")
        db.session.add(cliente)
        db.session.commit()

    
    if ItemCardapio.query.count() == 0:
        db.session.add_all([
            ItemCardapio(nome="Hambúrguer", preco=25.00, disponivel=True),
            ItemCardapio(nome="Refrigerante", preco=7.00, disponivel=True),
            ItemCardapio(nome="Batata frita", preco=15.00, disponivel=True),
        ])
        db.session.commit()
