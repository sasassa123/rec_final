from datetime import datetime
from decimal import Decimal

from models.db import db


class Comanda(db.Model):
    __tablename__ = "comandas"

    id = db.Column(db.Integer, primary_key=True)  
    status = db.Column(db.String(20), default="aberta", nullable=False)  

    cliente_id = db.Column(db.Integer, db.ForeignKey("clientes.id"))
    atendente_id = db.Column(db.Integer, db.ForeignKey("funcionarios.id"))

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    closed_at = db.Column(db.DateTime)
    paid_at = db.Column(db.DateTime)

    created_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    closed_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    paid_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id"))

    cliente = db.relationship("Cliente")
    atendente = db.relationship("Funcionario")

    itens = db.relationship("ItemComanda", back_populates="comanda", cascade="all, delete-orphan")
    pagamentos = db.relationship("Pagamento", back_populates="comanda", cascade="all, delete-orphan")

    def total(self):
        from decimal import Decimal
        return sum((item.subtotal for item in self.itens), Decimal("0.00"))

    def __repr__(self):
        return f"<Comanda {self.id} ({self.status})>"
