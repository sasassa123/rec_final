from models.db import db


class Funcionario(db.Model):
    __tablename__ = "funcionarios"

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    cargo = db.Column(db.String(50), nullable=False)  
    ativo = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f"<Funcionario {self.nome} ({self.cargo})>"
