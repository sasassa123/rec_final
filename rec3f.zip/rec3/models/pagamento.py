from datetime import datetime

from models.db import db


class Pagamento(db.Model):
    __tablename__ = "pagamentos"

    id = db.Column(db.Integer, primary_key=True)
    comanda_id = db.Column(db.Integer, db.ForeignKey("comandas.id"), nullable=False)

    forma_pagamento = db.Column(db.String(50), nullable=False)
    valor_total = db.Column(db.Numeric(10, 2), nullable=False)
    valor_recebido = db.Column(db.Numeric(10, 2), nullable=False)
    troco = db.Column(db.Numeric(10, 2), nullable=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)

    comanda = db.relationship("Comanda", back_populates="pagamentos")
