from flask import Flask, redirect, url_for
from models.db import db, login_manager
from utils.seed import seed_inicial
from utils.create_database import create_mysql_database_if_not_exists
import os
from models import (
    Role, User, Cliente, Funcionario,
    ItemCardapio, Comanda, ItemComanda, Pagamento
)
from controllers.auth_controller import auth_bp
from controllers.cardapio_controller import cardapio_bp
from controllers.comanda_controller import comanda_bp
from controllers.admin_controller import admin_bp


def create_app():

    
    create_mysql_database_if_not_exists(database_name="restaurante_db")

   
    app = Flask(
        __name__,
        template_folder=os.path.join(os.path.dirname(__file__), "..", "views"),
        static_folder=os.path.join(os.path.dirname(__file__), "..", "static")
    )

    app.config["SECRET_KEY"] = "chave-muito-secreta"
    app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:@localhost/restaurante_db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

 
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

   
    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(cardapio_bp, url_prefix="/cardapio")
    app.register_blueprint(comanda_bp, url_prefix="/comanda")
    app.register_blueprint(admin_bp, url_prefix="/admin")

   
    @app.route("/")
    def index():
        from flask_login import current_user

        if not current_user.is_authenticated:
            return redirect(url_for("auth.login"))

        if current_user.role and current_user.role.nome == "admin":
            return redirect(url_for("admin.dashboard"))

        if current_user.role and current_user.role.nome == "atendente":
            return redirect(url_for("comanda.listar_comandas"))

        return redirect(url_for("cardapio.ver_cardapio"))

 
    with app.app_context():
        db.create_all()
        seed_inicial()

    return app
