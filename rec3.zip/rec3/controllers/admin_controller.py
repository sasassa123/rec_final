from decimal import Decimal
from datetime import datetime

from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from models import db, Cliente, Pagamento, Comanda, ItemCardapio
from utils.decorators import role_required


admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/dashboard")
@login_required
@role_required("admin")
def dashboard():
    return render_template("admin_dashboard.html")


@admin_bp.route("/clientes")
@login_required
@role_required("admin")
def listar_clientes():
    clientes = Cliente.query.all()
    return render_template("admin_clientes_listar.html", clientes=clientes)

@admin_bp.route("/clientes/novo", methods=["GET", "POST"])
@login_required
@role_required("admin")
def novo_cliente():
    if request.method == "POST":
        nome = request.form.get("nome")
        email = request.form.get("email")
        telefone = request.form.get("telefone")

        if not nome:
            flash("Nome é obrigatório.", "warning")
            return redirect(url_for("admin.novo_cliente"))

        c = Cliente(nome=nome, email=email, telefone=telefone)
        db.session.add(c)
        db.session.commit()

        flash("Cliente cadastrado.", "success")
        return redirect(url_for("admin.listar_clientes"))

    return render_template("admin_clientes_form.html", cliente=None)

@admin_bp.route("/clientes/<int:cliente_id>/editar", methods=["GET", "POST"])
@login_required
@role_required("admin")
def editar_cliente(cliente_id):
    cliente = Cliente.query.get_or_404(cliente_id)

    if request.method == "POST":
        cliente.nome = request.form.get("nome")
        cliente.email = request.form.get("email")
        cliente.telefone = request.form.get("telefone")

        if not cliente.nome:
            flash("Nome é obrigatório.", "warning")
            return redirect(url_for("admin.editar_cliente", cliente_id=cliente_id))

        db.session.commit()
        flash("Cliente atualizado.", "success")
        return redirect(url_for("admin.listar_clientes"))

    return render_template("admin_clientes_form.html", cliente=cliente)

@admin_bp.route("/clientes/<int:cliente_id>/excluir", methods=["POST"])
@login_required
@role_required("admin")
def excluir_cliente(cliente_id):
    cliente = Cliente.query.get_or_404(cliente_id)
    db.session.delete(cliente)
    db.session.commit()

    flash("Cliente removido.", "info")
    return redirect(url_for("admin.listar_clientes"))


@admin_bp.route("/comanda/<int:comanda_id>/pagar", methods=["GET", "POST"])
@login_required
@role_required("admin")
def pagar_comanda(comanda_id):
    comanda = Comanda.query.get_or_404(comanda_id)

    
    if comanda.status != "fechada":
        flash("Só é possível pagar comandas fechadas.", "warning")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    if request.method == "POST":
        forma_pagamento = request.form.get("forma_pagamento")
        valor_recebido_str = request.form.get("valor_recebido") or "0"
        valor_recebido = Decimal(valor_recebido_str.replace(",", "."))

        total = comanda.total()

        if valor_recebido < total:
            flash("Valor insuficiente.", "danger")
            return redirect(url_for("admin.pagar_comanda", comanda_id=comanda_id))

        troco = valor_recebido - total

        pag = Pagamento(
            comanda_id=comanda.id,
            forma_pagamento=forma_pagamento,
            valor_total=total,
            valor_recebido=valor_recebido,
            troco=troco,
        )

        db.session.add(pag)

        comanda.status = "paga"
        comanda.paid_at = datetime.utcnow()
        comanda.paid_by_user_id = current_user.id

        db.session.commit()

        flash(f"Pagamento registrado. Troco: R$ {troco}", "success")
        return redirect(url_for("comanda.detalhar_comanda", comanda_id=comanda_id))

    return render_template("pagamento.html", comanda=comanda)
