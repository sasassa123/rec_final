from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from models.db import db, login_manager


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    role_id = db.Column(db.Integer, db.ForeignKey("roles.id"), nullable=False)
    cliente_id = db.Column(db.Integer, db.ForeignKey("clientes.id"), nullable=True)
    funcionario_id = db.Column(db.Integer, db.ForeignKey("funcionarios.id"), nullable=True)

    role = db.relationship("Role")
    cliente = db.relationship("Cliente")
    funcionario = db.relationship("Funcionario")

    def set_password(self, senha):
        self.password_hash = generate_password_hash(senha)

    def check_password(self, senha):
        return check_password_hash(self.password_hash, senha)

    def has_role(self, nome_role):
        return self.role and self.role.nome == nome_role


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
