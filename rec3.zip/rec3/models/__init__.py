from .db import db, login_manager
from .role import Role
from .user import User
from .cliente import Cliente
from .funcionario import Funcionario
from .item_cardapio import ItemCardapio
from .comanda import Comanda
from .item_comanda import ItemComanda
from .pagamento import Pagamento
