import pymysql

def create_mysql_database_if_not_exists(
    host="localhost",
    user="root",
    password="",
    database_name="restaurante_db"
):
    connection = pymysql.connect(host=host, user=user, password=password)
    cursor = connection.cursor()

    cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database_name}")
    connection.commit()

    cursor.close()
    connection.close()
